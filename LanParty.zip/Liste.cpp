#include "Liste.h"
#include <fstream>
#include <string>

using namespace std;

Liste::Liste()
{
    cap = NULL;
    nr_noduri = 0;
}

Liste::Liste(Nod *c):cap(c)
{

}

void Liste::afisare()
{
    Nod* p=cap;
    for(; p!=NULL; p=p->getUrm())
    {
        p->getEp()->afisare();
    }
}

void Liste::adaugaNodInceput(Echipa *echip)
{
    if(cap == NULL)
        cap = new Nod(echip);
    else
    {
        Nod* aux = new Nod(echip);
        aux->setUrm(cap);
        cap = aux;
    }

    nr_noduri++;
}
//M am gandit sa fac doua functii una care mi pune la inceput si una care pune la sfarsit pentru cerinte deoarece am vazut ca in checker
//se face afisarea liste invers si ca sa pot sa fac tot programul asa trebuie sa fac in doua feluri adougarile
//La adaugare la inceput practic verific daca capul e null daca e il aloc cu ajutorul construct cu parametru echipa
//daca nu e null fac un auxiliar pe care il aloc, pun in urmatorul auxiliar capul si in cap auxiliarul si cresc numarul de noduri

void Liste::adaugaNodSfarsit(Echipa *echip)
{
    if(cap == NULL)
        cap = new Nod(echip);
    else
    {
        Nod*p=cap;
        for(; p->getUrm()!=NULL; p=p->getUrm());
        Nod* aux = new Nod(echip);
        p->setUrm(aux);
    }

    nr_noduri++;
}
//in aceasta functie in prima partea a functie fac exact ceea ce fac si la adauga la inceput
//dar in cazul in care cappul e dif de null fac un for care parcurge lista cu ajutorul nodului p
//fac un aux pe care il aloc, iar p de urm ia valoarea lui aux
//cresc nr de noduri

void Liste::citesteLista(ifstream &f)
{
    int i,j,n;
    f>>n;
    for(i=0; i<n; i++)
    {
        int nr_jucatori;
        string nume_echipa;
        f>>nr_jucatori;
        f.get();
        getline(f,nume_echipa);
        if(nume_echipa.back() == ' ')
            nume_echipa.pop_back();
        adaugaNodInceput(new Echipa(nr_jucatori, nume_echipa));

        for(j=0; j<nr_jucatori; j++)
        {
            string nume, prenume;
            int puncte;
            f>>nume;
            f>>prenume;
            f>>puncte;
            cap->getEp()->addJuc(Jucator(nume, prenume, puncte)); //problema de razboi
        }
    }
}
//cistste lista imi ia din fisier si pun pe rand in elemte
//intai pun nr de echipe
//fac primul for pentru a pune pe rand in lista numele echipei si nr de jucatori
//al 2-lea for pentru vectorul de jucatori
// mai am cele deoua funtii back si pop pentru a elimina spatiile de la sfarsitul unor linii apar cateva exceptii
string Liste::puncteMin()
{
    float minim=100000;
    string n;
    Nod *p;
    for(p=cap; p!=NULL; p=p->getUrm())
    {
        if(minim>p->getEp()->verificaMedie())
        {
            minim=p->getEp()->verificaMedie();
            n=p->getEp()->getNech();
        }
    }
    return n;
}
//imi o funstie care imi retuneaza minimul foloseste functie de medie pentru a putea face o clasificare sa stim ce sa eliminam la cerinta 2
void Liste::stergeEchipe()
{
    Nod *p;
    Nod *aux;
    int n_max=1, copie=1;

    while(nr_noduri>=copie)
    {
        n_max=copie;
        copie = copie * 2;
    }
//functie de stergere fac un while pentru a gasi numarul max de echipe face o copie care se inmulteste cu 2 pana cand ajunge mai mica de n
    while(nr_noduri>n_max)
    {
        string minim = puncteMin();
        Nod* prec;
        for(p=cap, prec=NULL; p!=NULL; prec=p, p=p->getUrm())
        {

            if(p->getEp()->getNech()==minim)
            {
                if(prec == NULL)
                {
                    aux=cap;
                    cap=cap->getUrm();
                }
                else
                {
                    aux=p;
                    prec->setUrm(p->getUrm());
                }
                delete aux;
                nr_noduri--;
                break;
            }
        }
    }
}
//pentru stergere echipa erificdaca punctajul este egal cu return ul de la functia precedenta
//daca e egala o elimin
//elimin echipe pana raman cu nmax echipe cal la inceputul functiei
int Liste::lungime()
{
    Nod*p;
    int n;
    for(p=cap; p!=NULL; p=p->getUrm())
    {
        n++;
    }
    return n;
}
//fac o functie care parcurge lista si numara nodurile
Nod* Liste::getCap()
{
    return cap;
}
void Liste::afiseazaLista(ofstream& rez)
{
    Nod* p=cap;
    for(; p!=NULL; p=p->getUrm())
        rez<<p->getEp()->getNech()<<endl;
}


int Liste::getNr_noduri()
{
    return nr_noduri;
}

Liste::~Liste()
{
    Nod *p=cap;
    while(p!=NULL)
    {
        Nod* aux=p;
        p=p->getUrm();
        if(aux)
            delete aux;

    }
}
//Eliberam memoria pentru lista
