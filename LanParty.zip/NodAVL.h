#include"Echipa.h"
//este apoximativ la fel ca nodul arbore stiu ca puteam sa mostenesc ca am adaugat doar inaltimea dar m-am gandit ca tehnic nu
//ar trebui pentru ca tema se bazaza pe primele 6 cursuri deci am facut asa
//am operatorul =, const de copier si destructor pentru a functiona corect +setteri si getteri
class NodAVL
{
    int h;//inaltimea arborelui
    Echipa*echipa;
    NodAVL *stanga, *dreapta;
public:
    NodAVL();
    NodAVL(int inaltime, Echipa*e, NodAVL *s,NodAVL *d);
    NodAVL(const NodAVL &n);
    NodAVL& operator=(const NodAVL &n);
    ~NodAVL ();

    int getH();
    Echipa*getEchipa();
    NodAVL *getD();
    NodAVL *getS();

    void setH(int h);
    void setEchipa(Echipa*e);
    void setD(NodAVL*d);
    void setS(NodAVL*s);
};
