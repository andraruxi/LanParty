#include"Meci.h"
#include"NodCoada.h"
#include "Liste.h"
#include "Stiva.h"

class Coada
{
    NodCoada *fata,*spate;
    //avem doua noduri care pointeaza sper spatele si fata cozii
public:
    Coada();
    Coada(NodCoada *f, NodCoada  *s);
    ~Coada();

    NodCoada *getFata();
    NodCoada *getSpate();

    void setFata(NodCoada *f);
    void setSpate(NodCoada *s);

    void adaugaElement(Meci *m);
    Meci *stergeElement();
    int coadaGoala();

    void creeazaMeciuriInitiale(Liste* l);
    void creeazaMeciuri(Stiva* castigatori);
    int puneEchipe(Stiva* castigatori, Stiva* invinsi, ofstream& rez, int nr_meci);
    void puneSpatiiMeciuri(ofstream& rez, int len);
    void afiseazaMeci(ofstream& rez, Meci* m);
};
