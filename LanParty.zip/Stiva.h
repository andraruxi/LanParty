#include "Liste.h"
#include <fstream>
#pragma once
//folosec acelasi nod pe care l-am folosit si la lista
class Stiva
{   //ELIBERARE MEMORIE!!!!!!!!!!!!!!!!1
    Nod *cap_stiva;
public:
    Stiva();
    Stiva(Nod *c);
    ~Stiva();

    Nod* getCapStiva();
    void setCapStiva(Nod *cap);

    void adaugaElement(Echipa*e);
    Echipa* stergeElement();
    int goala();

    void puneSpatiiStiva(ofstream& rez, int len);
    void afiseazaStiva(ofstream& rez);
    void stergeStiva();
    void stergeStivaDupaTop8();
    Liste* creeazaLista();
};
