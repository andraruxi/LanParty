#include"BTS.h"

BTS::BTS()
{
    radacina=NULL;
}

BTS::BTS(NodArbori *r):radacina(r)
{

}

NodArbori *BTS::getRadacina()
{
    return radacina;
}

void BTS::adaugare(Echipa* e)
{
    if(radacina==NULL)
    {
        radacina=new NodArbori(e);
        return;
    }
    adaugareAux(radacina, e);
}
//am folosit doua functii adaugare care practic imi creeaza radacina principala si dupa am o functie auziliara de adaugare
//care practic imi completeaza arborele
//am facut acest lucru pentru ca in momentul in care imi apela functia de adaugare nu imi baga in arbore
//m am gandit sa fac asa
NodArbori* BTS::adaugareAux(NodArbori* nod,Echipa* e)
{
    if(nod==NULL)
    {
        nod=new NodArbori(e);
    }
    else if(e->verificaMedie()>nod->getEchipa()->verificaMedie())//verifiv punctajul echipei si vad pe ce parte sa l pun stanga sau dreapta
        nod->setDreapta(adaugareAux(nod->getDreapta(), e));//mai mare
    else if(e->verificaMedie()<nod->getEchipa()->verificaMedie())
        nod->setStanga(adaugareAux(nod->getStanga(), e));//mai mic
    else if(e->getNech()>nod->getEchipa()->getNech())// in functie de nume invers alfabetic
        nod->setDreapta(adaugareAux(nod->getDreapta(), e));
    else
        nod->setStanga(adaugareAux(nod->getStanga(), e));
    return nod;
}

void BTS::creeazaBTS(Liste* l)
{
    Nod* p=l->getCap();
    for(; p!=NULL; p=p->getUrm())
        adaugare(p->getEp());
}
//in face arborele in care folosesc functia de adaugare
void BTS::puneSpatii(ofstream& rez, int len)
{
    for(int i=0; i<len; i++)
        rez<<" ";
}

void BTS::afiseazaDescresc(NodArbori* nod, ofstream& rez, Liste* BOMBA)
{
    if(nod==NULL)
        return;
    afiseazaDescresc(nod->getDreapta(), rez, BOMBA);
    rez<<nod->getEchipa()->getNech();
    puneSpatii(rez, 34-nod->getEchipa()->getNech().length());
    rez<<"-  "<<nod->getEchipa()->verificaMedie()<<endl;
    BOMBA->adaugaNodSfarsit(nod->getEchipa());
    afiseazaDescresc(nod->getStanga(), rez, BOMBA);//bomba e de fapt o lista auxiliara
}
//metoda care imi pune in fisier cu spatiile necesaree si in ordine

//Eliberare memorie
void BTS::stergeRad(NodArbori* nod)
{
    //cout<<"kys"<<endl;
    if(nod==NULL)
    {
        return;
    }
    stergeRad(nod->getStanga());
    stergeRad(nod->getDreapta());
    if(nod)
        delete nod;
}

BTS::~BTS()
{
    stergeRad(radacina);
    radacina=NULL;
}
