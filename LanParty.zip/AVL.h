#include"NodAVL.h"
#include"Liste.h"
#include <fstream>
//folosec prin agregare clasa nodAVl
class AVL
{
    NodAVL *rad;
public:
    AVL();
    AVL(NodAVL *r);
    int aflareH(NodAVL*rada);
    NodAVL* rotatieDreapta(NodAVL*rad);
    NodAVL *rotatieStanga(NodAVL*rad);
    NodAVL* rotatieLR(NodAVL*rad);
    NodAVL* rotatieRL(NodAVL*rad);
    NodAVL *adaugare(NodAVL*rad, Echipa*e);
    NodAVL* adaugareAux(NodAVL*nod, Echipa*e);
    void creeazaAVL(Liste* l);
    void afiseazaNivel2(ofstream& rez);
    void stergeNod(NodAVL*nod);
    ~AVL();
};
