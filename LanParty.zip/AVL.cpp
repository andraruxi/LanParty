#include"AVL.h"
AVL::AVL()
{
    rad=NULL;
}

AVL::AVL(NodAVL *r):rad(r)
{
    //cout<<"con cu par";
}

int AVL::aflareH(NodAVL *rada)
{
    if(rada==NULL)
        return -1;				// AICI ERA -1
    else
        return rada->getH();
}

NodAVL *AVL::rotatieDreapta(NodAVL*rada)
{
    //cazul LL->reechilibrare prin rot la dreapta

    NodAVL *rad2=NULL;
    if(rada!=NULL)
        rad2=rada->getS();
    NodAVL *rad3=NULL;
    if(rad2!=NULL)
        rad3=rad2->getD();


    //Roteste
    if(rada!=NULL)
        rad2->setD(rada);
    if(rad3!=NULL)
        rada->setS(rad3);

    rada->setH(max(aflareH(rada->getS()),aflareH(rada->getD()))+1);
    rad2->setH(max(aflareH(rad2->getS()),aflareH(rad2->getD()))+1);
    return rad2;
}

NodAVL *AVL::rotatieStanga(NodAVL*rada)
{
    //reechilibrarea prin rotatie la stanga
    NodAVL *rad2=NULL;
    if(rada!=NULL)
        rad2=rada->getD();
    NodAVL *rad3=NULL;
    if(rad2!=NULL)
    {

        rad3=rad2->getS();
    }

    //Roteste
    rad2->setS(rada);
    rada->setD(rad3);

    //Updateaza inaltimea
    rada->setH(max(aflareH(rada->getS()),aflareH(rada->getD()))+1);
    rad2->setH(max(aflareH(rad2->getS()),aflareH(rad2->getD()))+1);


    return rad2;
}

NodAVL *AVL::rotatieLR(NodAVL*rada)
{
    //rotatie la stanga+rotatie la dreapta
    rada->setS(rotatieStanga(rada->getS()));
    return rotatieDreapta(rada);
}

NodAVL *AVL::rotatieRL(NodAVL*rada)
{
    //rotatie la dreapta+rot la stanga
    rada->setD(rotatieDreapta(rada->getD()));
    return rotatieStanga(rada);
}

NodAVL* AVL::adaugare(NodAVL*nod,Echipa*e)
{
    //1. insereaza nod
    if(rad==NULL)
    {

        rad=new NodAVL();
        rad->setEchipa(e);
        rad->setH(0);
        rad->setD(NULL);
        rad->setS(NULL);
        return rad;
    }//adauga nod
    rad = adaugareAux(rad, e);
    return rad;
}

NodAVL* AVL::adaugareAux(NodAVL*nod,Echipa*e)
{
    //cout<<nod->getEchipa()->getNech()<< " ";
    if(nod==NULL)
    {

        nod=new NodAVL();
        nod->setEchipa(e);
        //nod->setH(0);
        // rad->setD(NULL);
        //rad->setS(NULL);
        return nod;
    }//adauga nod
    if(nod!=NULL)
    {
        if(e->verificaMedie()<=nod->getEchipa()->verificaMedie())
        {
            NodAVL* aux = adaugareAux(nod->getS(),e);
            nod->setS(aux);

        }
        else //if(e->verificaMedie()>=nod->getEchipa()->verificaMedie())
        {
            NodAVL* aux = adaugareAux(nod->getD(),e);
            nod->setD(aux);
        }
        //else return nod;
        //nu am chei duplicate

        //2.updateaza h nod stramos

        nod->setH(1+max(aflareH(nod->getS()),aflareH(nod->getD())));

        //3.afla factorul de echil al nod stramois
        int k=(aflareH(nod->getS())-aflareH(nod->getD()));

        //4.daca nodul nu e echilibrat echilibreaza-l
        //ll case
        // if(nod!=NULL)
        if(k>1 && e->verificaMedie()<=nod->getS()->getEchipa()->verificaMedie())
            return rotatieDreapta(nod);

        //rr case
        if(k<-1 && e->verificaMedie()>nod->getD()->getEchipa()->verificaMedie())
            return rotatieStanga(nod);

        //lr case
        if(k>1 && e->verificaMedie()>=nod->getS()->getEchipa()->verificaMedie())
            return rotatieRL(nod);

        //rl case
        if(k<-1 && e->verificaMedie()<nod->getD()->getEchipa()->verificaMedie())
            return rotatieLR(nod);

        return nod;
        //se returneaza nodul nemodificatr*/
    }
}

void AVL::creeazaAVL(Liste* l)
{
    Nod* p=l->getCap();
    for(; p!=NULL; p=p->getUrm())//aici era p!=NULL
    {

        rad = adaugare(rad,p->getEp());
    }

}

void AVL::afiseazaNivel2(ofstream& rez)
{
    NodAVL* stanga=rad->getS();
    NodAVL* dreapta=rad->getD();
    rez<<endl<<"THE LEVEL 2 TEAMS ARE: "<<endl;


    rez<<dreapta->getD()->getEchipa()->getNech()<<endl;
    rez<<dreapta->getS()->getEchipa()->getNech()<<endl;
    rez<<stanga->getD()->getEchipa()->getNech()<<endl;
    rez<<stanga->getS()->getEchipa()->getNech()<<endl;


}

void AVL::stergeNod(NodAVL*nod)
{
    if(nod==NULL)
        return;
    stergeNod(nod->getS());
    stergeNod(nod->getD());
    if(nod)
    {
        delete nod;
        nod=NULL;
    }
}

AVL::~AVL()
{
    stergeNod(rad);
    rad=NULL;
}
