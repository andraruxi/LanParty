#include"NodArbori.h"
#include "Liste.h"
#include <fstream>
// stiu ca avem arbore Bst (binary search tree) dar cand am scris clasa nu mi-am dat seama era f tarziu si mi-a fost frica
//sa nu stric ceva de aceea am lasat o asa
//Clasa mea are un atribut de tip nod arbore si ii dam o radacina
class BTS
{
    NodArbori *radacina;
public:
    BTS();
    BTS(NodArbori *r);
    NodArbori *getRadacina();
    NodArbori nodNou();
    void adaugare(Echipa* e);
    NodArbori* adaugareAux(NodArbori* nod,Echipa* e);
    void creeazaBTS(Liste* l);

    void puneSpatii(ofstream& rez, int len);
    void afiseazaDescresc(NodArbori* nod, ofstream& rez, Liste*BOMBA);
    void stergeRad(NodArbori*nod);
    ~BTS();
};
