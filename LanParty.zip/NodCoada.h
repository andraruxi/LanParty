#include"Meci.h"
class NodCoada
{
    Meci *m;
    NodCoada *urm;
public:
    NodCoada();
    NodCoada(Meci *m1);
    NodCoada(Meci*m2, NodCoada *u);
    NodCoada(const NodCoada &n);
    NodCoada& operator=(const NodCoada &n);
    ~NodCoada();

    Meci* getM();
    NodCoada *getUrmCoada();

    void setM(Meci*m);
    void setUrmCoada(NodCoada *urm);
};
