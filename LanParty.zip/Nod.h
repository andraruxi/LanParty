#include"Echipa.h"
#pragma once
//acesta clasa va fi folosita ca nod atat pentru lista cat si pentru stiva
class Nod
{
    Echipa* ep;
    Nod *urm;
public:
    Nod();
    Nod(Echipa *e);
    Nod(Echipa *e, Nod *u);
    Nod(const Nod &n);
    Nod &operator=(const Nod&n);
    ~Nod();

    Echipa* getEp();
    Echipa* getCopieEp();
    Nod *getUrm();

    void setEp(Echipa *ep);
    void setUrm(Nod *urm);
};
