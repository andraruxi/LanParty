#include"NodArbori.h"

NodArbori::NodArbori()
{
    echip=NULL;
    stanga=NULL;
    dreapta=NULL;
}

NodArbori::NodArbori(Echipa*e, NodArbori *s, NodArbori*d)
{
    if(e!=NULL)
    {
        echip=new Echipa();
        echip=e;
    }
    else echip=NULL;

    if(s!=NULL)
    {
        stanga=new NodArbori();
        stanga=s;

    }
    else stanga=NULL;

    if(d!=NULL)
    {
        dreapta=new NodArbori();
        dreapta=d;

    }
    else dreapta=NULL;
}

NodArbori::NodArbori(Echipa* e)
{
    if(e!=NULL)
    {
        echip=new Echipa();
        echip=e;
    }
    else echip=NULL;

    stanga=NULL;
    dreapta=NULL;
}


NodArbori::NodArbori(const NodArbori &a)
{
    if(a.echip!=NULL)
    {
        echip=new Echipa();
        echip=a.echip;
    }
    else echip=NULL;

    if(a.stanga!=NULL)
    {
        stanga=new NodArbori();
        stanga=a.stanga;

    }
    else stanga=NULL;

    if(a.dreapta!=NULL)
    {
        dreapta=new NodArbori();
        dreapta=a.dreapta;

    }
    else dreapta=NULL;
}

NodArbori& NodArbori::operator=(const NodArbori &a)
{
    if(echip!=NULL)
        delete echip;
    if(a.echip!=NULL)
    {
        echip=new Echipa();
        echip=a.echip;
    }
    else echip=NULL;

    return *this;
}

NodArbori::~NodArbori()
{
    if(echip!=NULL)
    {
        delete echip;
        echip=NULL;
    }
}
//Constructor de copiere , op= si destructorul sunt neceesari pentru o functinare corecta
Echipa* NodArbori::getEchipa()
{
    return echip;
}

NodArbori *NodArbori::getStanga()
{
    return stanga;

}

NodArbori *NodArbori::getDreapta()
{
    return dreapta;
}

NodArbori **NodArbori::getStangaP()
{
    return &stanga;

}

NodArbori **NodArbori::getDreaptaP()
{
    return &dreapta;
}

void NodArbori::setEchipa(Echipa *e)
{
    if(echip!=NULL)
        delete echip;
    echip=new Echipa();
    echip=e;
}

void NodArbori::setStanga(NodArbori *s)
{
    stanga=s;
}

void NodArbori::setDreapta(NodArbori *d)
{
    dreapta=d;
}
//setteri si getteri ne vom folosi de ei epntru ca avem functi cu atr private
