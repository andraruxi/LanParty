#include"NodCoada.h"
NodCoada::NodCoada()
{
    m=NULL;
    urm=NULL;
}

NodCoada::NodCoada(Meci *m1)
{
    if(m1!=NULL)
    {
        m=new Meci();
        m=m1;

    }
    else m=NULL;

    urm=NULL;
}

NodCoada::NodCoada(Meci *m2, NodCoada *u)
{
    if(m2!=NULL)
    {
        m=new Meci();
        m=m2;

    }
    else m=NULL;
    if(u!=NULL)
    {
        urm=new NodCoada();
        urm=u;
    }
    else urm=NULL;

}

NodCoada::NodCoada(const NodCoada &n)
{

   if(n.m!=NULL)
    {
        m=new Meci();
        m=n.m;
    }
    else m=NULL;

    if(n.urm!=NULL)
    {
        urm=new NodCoada();
        urm=n.urm;
    }
    else urm=NULL;

}

NodCoada &NodCoada::operator=(const NodCoada &n)
{
    if(m!=NULL)
        delete m;
    if(n.m!=NULL)
    {
        m=new Meci();
        m=n.m;
    }
    else m=NULL;

    return *this;

}

NodCoada::~NodCoada()
{
    if(m!=NULL)
    {
        delete m;
        m=NULL;
    }
}
//La fel ca nodul pentru lista si stiva se comporta la fel insa in loc sa primeasca o echipa primeste un meci
//avem nevoie de const de copiere , op= si destructor pentru ca avem poineter de meciuri
 Meci* NodCoada::getM()
 {
    return m;
 }

 NodCoada *NodCoada::getUrmCoada()
{
    return urm;
}

void NodCoada::setM(Meci* m)
{
    this->m=m;
}

void NodCoada::setUrmCoada(NodCoada *urm)
{
    this->urm=urm;
}
