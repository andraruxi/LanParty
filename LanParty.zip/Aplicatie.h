#include <iostream>
#include <fstream>
#include"Jucator.h"
#include"Liste.h"
#include "Coada.h"
#include"Stiva.h"
#include "BTS.h"
#include "AVL.h"

class Aplicatie
{
    ifstream cerinte;
    ifstream date;
    ofstream rezultate;

    Liste *lista;
    Liste *listaTop8;
    Coada *coada;
    Stiva *castigatori;
    Stiva *invinsi;
    BTS* bts;
    AVL* avl;
    Liste *BOMBA;

public:
    Aplicatie();
    Aplicatie(char* fisier1, char* fisier2, char* fisier3);
    ~Aplicatie();

    void completeazaStivele();
    void creareMeciStiva();
    void stergeCoada(Coada *c);

    void run();
    void cerinta1();
    void cerinta2();
    void cerinta3();
    void cerinta4();
    void cerinta5();
};
