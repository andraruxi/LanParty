#include"Coada.h"
#include <fstream>
Coada::Coada()
{
    fata=NULL;
    spate=NULL;
}

Coada::Coada(NodCoada *f, NodCoada *s):fata(f),spate(s)
{
    //cout<<"Cons cu par coada";
}

NodCoada *Coada::getFata()
{
    return fata;
}

NodCoada* Coada::getSpate()
{
    return spate;
}



void Coada::adaugaElement (Meci*m)
{
    NodCoada *nod = new NodCoada(m);

    //daca nodul nou nu se gasete la finalul cozii
    if(spate==NULL) //daca nu e niciun nod in coada
        spate=nod;
    else
    {
        spate->setUrmCoada(nod);
        spate=nod;
    }

    if(fata==NULL) fata=spate; //daca e singurul element din coada

}

int Coada::coadaGoala()
{
    return (fata==NULL);
}

Meci* Coada::stergeElement()
{
    if(coadaGoala())
        return NULL;
    NodCoada *aux;
    Meci*m;
    aux=fata;
    m=aux->getM();
    fata=fata->getUrmCoada();
    //delete aux;
    aux=NULL;
    return m;
}
//sterg un element din coada

void Coada::creeazaMeciuriInitiale(Liste* lista)
{
    Nod* p;
    for(p=lista->getCap(); p!=NULL; p=p->getUrm())//parcurg lista creata
    {
        adaugaElement(new Meci(p->getEp(), p->getUrm()->getEp()));//functia adauga si pun in coada
        p=p->getUrm();//setez urmatorul
    }
}

void Coada::creeazaMeciuri(Stiva* castigatori)
{
    while(!castigatori->goala())
        adaugaElement(new Meci(castigatori->stergeElement(), castigatori->stergeElement()));
        //o folosesc pentru a pune din stiva de castigatori meciuri inapoi in coada
}

void Coada::puneSpatiiMeciuri(ofstream& rez, int len)
{
    for(int i=0; i<len; i++)
        rez<<" ";
        //o functie de adaugare a spatiilor
}

void Coada::afiseazaMeci(ofstream& rez, Meci* m)
{
    rez<<m->getE1()->getNech();
    puneSpatiiMeciuri(rez, 33-m->getE1()->getNech().length());
    rez<<"-";
    puneSpatiiMeciuri(rez, 33-m->getE2()->getNech().length());
    rez<<m->getE2()->getNech()<<endl;
}
//in fisier o sa pun meciurile exeact cum sunt in aut cu spatii
// dupa cum am numarat acem 33 de spatii intre primul nume si - , la fel in ambele parti

int Coada::puneEchipe(Stiva* castigatori, Stiva* invinsi, ofstream& rez, int nr_meci)
{
    int nr_castigatori=0;
    rez<<endl<<"--- ROUND NO:"<<nr_meci<<endl;
    while(!coadaGoala())//verific daca e coada goala
    {
        Meci* m = stergeElement();//sterg meciri

        afiseazaMeci(rez, m);

        castigatori->adaugaElement(m->verificaCastigator());// pun in stiva de castigatori si invinsi cu ajuto funtiilor din meci
        invinsi->adaugaElement(m->verificaInvinsi());
        nr_castigatori++;//cresc nr de castigatori
    }

    rez<<endl<<"WINNERS OF ROUND NO:"<<nr_meci<<endl;
    castigatori->afiseazaStiva(rez);// afisez

    if(nr_castigatori>=8)
        invinsi->stergeStiva();//sterg stiva de invinsi daca daca nr de castig e mai mare ca 8
    else
    {
        invinsi->stergeStivaDupaTop8();//daca nu sterg stiva dupa ce fac lista cu cei top 8
    }
    return nr_castigatori;// afisez nr de catsigatori
}

Coada::~Coada()
{
    NodCoada* p=fata, *aux;
    while(p)
    {
        aux=p;
        p=p->getUrmCoada();
        if(aux)
            delete aux;
    }
}
