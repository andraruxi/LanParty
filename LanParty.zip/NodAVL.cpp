#include"NodAVL.h"
NodAVL::NodAVL():h(0)
{
    echipa=NULL;
    dreapta=NULL;
    stanga=NULL;

}

NodAVL::NodAVL(int inaltime, Echipa*e,NodAVL*d ,NodAVL*s):h(inaltime)
{
    if(e!=NULL)
    {
        echipa=new Echipa();
        echipa=e;
    }
    else echipa=NULL;

    if(d !=NULL)
    {
        dreapta=new NodAVL();
        dreapta=d ;
    }
    else dreapta=NULL;

    if(s!=NULL)
    {
        stanga=new NodAVL();
        stanga=s;
    }
    else stanga=NULL;
}

NodAVL::NodAVL(const NodAVL &n):h(n.h)
{
    if(n.echipa!=NULL)
    {
        echipa=new Echipa();
        echipa=n.echipa;
    }
    else echipa=NULL;

    if(n.dreapta !=NULL)
    {
        dreapta=new NodAVL();
        dreapta=n.dreapta ;
    }
    else dreapta=NULL;

    if(n.stanga!=NULL)
    {
        stanga=new NodAVL();
        stanga=n.stanga;
    }
    else stanga=NULL;

}

NodAVL& NodAVL::operator=(const NodAVL &n)
{
    h=n.h;
    if(echipa!=NULL)
        delete echipa;
    if(n.echipa!=NULL)
    {
        echipa=new Echipa();
        echipa=n.echipa;
    }
    else echipa=NULL;

   return *this;
}

NodAVL::~NodAVL()
{
    if(echipa!=NULL)
    {
        delete echipa;
        echipa=NULL;
    }
}

int NodAVL::getH()
{
    return h;
}

Echipa*NodAVL::getEchipa()
{
    return echipa;
}

NodAVL *NodAVL::getD()
{
    return dreapta;
}

NodAVL *NodAVL::getS()
{
    return stanga;
}

void NodAVL::setH(int h)
{
    this->h=h;
}

void NodAVL::setEchipa(Echipa*e)
{
    echipa=e;
}

void NodAVL::setD(NodAVL*d)
{
    dreapta=d;
}

void NodAVL::setS(NodAVL*s)
{
    stanga=s;
}
