#include"Stiva.h"
#include <iomanip>

Stiva::Stiva()
{
   cap_stiva=NULL;

}

Stiva::Stiva(Nod*c):cap_stiva(c)
{

}

 Nod* Stiva::getCapStiva()
 {
    return cap_stiva;
 }

 void Stiva::setCapStiva(Nod *cap)
 {
    cap_stiva=cap;
 }

void Stiva::adaugaElement(Echipa *e)
{
    Nod* nod_nou=new Nod();
    nod_nou->setEp(e);
    nod_nou->setUrm(cap_stiva);
    cap_stiva=nod_nou;
}
//fonstie de adaugare ma folosesc de un nod nou pe care il aloc
//echipa din nod o setez cu echipa data ca parametru
//urmatorul din nod il setez cu capul stivei
// in stiva bag de jos in sus primul elemet bagat e de fapt ultimul adica se pune peste el
int Stiva::goala()
{
    return (cap_stiva==NULL);
}

Echipa* Stiva::stergeElement()
{
    if(goala())
        return NULL;

    Nod *temp;
    temp=cap_stiva; //stocheaza adresa varfului in temp
    Echipa *aux=temp->getEp();
    temp->setEp(NULL);
    cap_stiva=cap_stiva->getUrm();

    delete temp;//eliberez memoria

    temp=NULL;
    return aux;
}

void Stiva::puneSpatiiStiva(ofstream& rez, int len)
{
    for(int i=0; i<len; i++)
        rez<<" ";
}
//la fel o metoda care imi pune spatii

void Stiva::afiseazaStiva(ofstream& rez)
{
    Nod* p;
    for(p=cap_stiva; p!=NULL; p=p->getUrm())
    {
        rez<<p->getEp()->getNech();
        puneSpatiiStiva(rez, 34-p->getEp()->getNech().length());
        rez<<"-  "<<setprecision(2)<<fixed<<p->getEp()->verificaMedie()<<endl;//imi aranjeaza frumos stiva  si pune sa afiseze scorul fix cu 2 zecimale
    }
}


void Stiva::stergeStiva()
{
    Nod *temp;
    while(!goala())
    {
        temp=cap_stiva;
        cap_stiva=cap_stiva->getUrm();
        delete temp;
    }
}
// sterge toata stiva=>eliberare memo
void Stiva::stergeStivaDupaTop8()
{
    Nod *temp;
    while(!goala())
    {
        temp=cap_stiva;
        cap_stiva=cap_stiva->getUrm();
        temp=NULL;
    }
}
//o sa folosesc acesta functie pentru a putea lucra mai usor dupa ce formez lista de 8 pentru ca eu trebuie sa pastrez

Liste* Stiva::creeazaLista()
{
    Liste* l=new Liste();
    Nod* p=cap_stiva;
    while(p)
    {
        l->adaugaNodInceput(p->getCopieEp());
        p=p->getUrm();
    }
    return l;
}

Stiva::~Stiva()
{
    stergeStiva();
}
