#include"Echipa.h"

class NodArbori
{
    Echipa *echip;
    NodArbori *stanga, *dreapta;
public:
    NodArbori();
    NodArbori(Echipa* e);
    NodArbori(Echipa* e, NodArbori *s,NodArbori *d);
    NodArbori(const NodArbori &a);
    NodArbori &operator=(const NodArbori &a);
    ~NodArbori();

    Echipa* getEchipa();
    NodArbori* getStanga();
    NodArbori* getDreapta();

    NodArbori **getStangaP();
    NodArbori **getDreaptaP();

    void setEchipa(Echipa*e);
    void setStanga(NodArbori*s);
    void setDreapta(NodArbori*d);
};
