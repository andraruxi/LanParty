#include"Nod.h"
#include"Meci.h"
#pragma once
class Liste
{
    Nod *cap;
    int nr_noduri;
public:

    Liste();
    Liste(Nod *c);

    void adaugaNodInceput(Echipa *echip);
    void adaugaNodSfarsit(Echipa *echip);
    void citesteLista( ifstream& f);
    string puncteMin();
    void stergeEchipe();
    int lungime();
    Nod*getCap();
    int getNr_noduri();

    void afisare();
    void afiseazaLista(ofstream& rez);
    ~Liste();
};
