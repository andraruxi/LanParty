#include"Nod.h"
Nod::Nod()
{
    ep=NULL;
    urm=NULL;
}
Nod::Nod(Echipa *e)
{
    ep=e;
    urm=NULL;
}

Nod::Nod(Echipa *e, Nod *u)
{


    ep=new Echipa();
    ep=e;


    if(u!=NULL)
    {
        urm=new Nod();
        urm=u;
    }
    else
        urm=NULL;

}
Nod::Nod(const Nod &n)
{

    if(n.ep!=NULL)
    {
        ep=new Echipa();
        ep=n.ep;
    }
    else
        ep=NULL;

    if(n.urm!=NULL)
    {
        urm=new Nod();
        urm=n.urm;
    }
    else
        urm=NULL;

}
Nod& Nod::operator=(const Nod&n)
{
    if(ep!=NULL)
        delete ep;
    if(n.ep!=NULL)
    {
        ep=new Echipa();
        ep=n.ep;
    }
    else
        ep=NULL;
    /* if(n.urm!=NULL)
     {
         urm=new Nod();
         urm=n.urm;
     }
     else urm=NULL;//aici am pus urm*/

    return *this;

}

Nod::~Nod()
{
    if(ep!=NULL)
    {
        delete ep;
        ep=NULL;
    }

}
//nu eliberez memorie pentru urm pentru ca o sa imi distruga toate legaturile


Echipa* Nod::getEp()
{
    return ep;
}

Echipa* Nod::getCopieEp()
{
    return new Echipa(*ep);
}

Nod *Nod::getUrm()
{
    return urm;
}

void Nod::setEp(Echipa *ep)
{
    this->ep=ep;
}

void Nod::setUrm(Nod *urm)
{
        this->urm=urm;
}

//implemetez getteri si setari pentru ca ma voi ajuta de ei
//alabil pentru toate clasele!!!!
